#!/bin/bash

# load-ls-main :: load-ls-8b230416728e48e57b7785efb147227e6bb19c5929f74d5008216efd259ced5d

# Navigate to core path
cd ../../.. || exit 1

# Body

# If the run has already been run before, it can be skipped
if [ -f "temp/runs/load-ls-8b230416728e48e57b7785efb147227e6bb19c5929f74d5008216efd259ced5d/logs_ns3/finished.txt" ] && [ $(< "temp/runs/load-ls-8b230416728e48e57b7785efb147227e6bb19c5929f74d5008216efd259ced5d/logs_ns3/finished.txt") == "Yes" ] ; then
    exit 0
fi

# Perform the run
cd frameworks/ns-3-bs/ns-3 || exit 1
./waf --run="main-full-pfifo-protocol --run_dir='../../../temp/runs/load-ls-8b230416728e48e57b7785efb147227e6bb19c5929f74d5008216efd259ced5d'" || exit 1

