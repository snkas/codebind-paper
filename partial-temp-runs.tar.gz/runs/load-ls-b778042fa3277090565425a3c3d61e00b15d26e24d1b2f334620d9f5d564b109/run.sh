#!/bin/bash

# load-ls-main :: load-ls-b778042fa3277090565425a3c3d61e00b15d26e24d1b2f334620d9f5d564b109

# Navigate to core path
cd ../../.. || exit 1

# Body

# If the run has already been run before, it can be skipped
if [ -f "temp/runs/load-ls-b778042fa3277090565425a3c3d61e00b15d26e24d1b2f334620d9f5d564b109/logs_ns3/finished.txt" ] && [ $(< "temp/runs/load-ls-b778042fa3277090565425a3c3d61e00b15d26e24d1b2f334620d9f5d564b109/logs_ns3/finished.txt") == "Yes" ] ; then
    exit 0
fi

# Perform the run
cd frameworks/ns-3-bs/ns-3 || exit 1
./waf --run="main-full-pfifo-protocol --run_dir='../../../temp/runs/load-ls-b778042fa3277090565425a3c3d61e00b15d26e24d1b2f334620d9f5d564b109'" || exit 1

