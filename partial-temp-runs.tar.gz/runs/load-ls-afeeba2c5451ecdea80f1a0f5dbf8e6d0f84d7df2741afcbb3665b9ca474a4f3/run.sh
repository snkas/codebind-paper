#!/bin/bash

# load-ls-main :: load-ls-afeeba2c5451ecdea80f1a0f5dbf8e6d0f84d7df2741afcbb3665b9ca474a4f3

# Navigate to core path
cd ../../.. || exit 1

# Body

# If the run has already been run before, it can be skipped
if [ -f "temp/runs/load-ls-afeeba2c5451ecdea80f1a0f5dbf8e6d0f84d7df2741afcbb3665b9ca474a4f3/logs_ns3/finished.txt" ] && [ $(< "temp/runs/load-ls-afeeba2c5451ecdea80f1a0f5dbf8e6d0f84d7df2741afcbb3665b9ca474a4f3/logs_ns3/finished.txt") == "Yes" ] ; then
    exit 0
fi

# Perform the run
cd frameworks/ns-3-bs/ns-3 || exit 1
./waf --run="main-full-pfifo-protocol --run_dir='../../../temp/runs/load-ls-afeeba2c5451ecdea80f1a0f5dbf8e6d0f84d7df2741afcbb3665b9ca474a4f3'" || exit 1

