#!/bin/bash

# load-ls-main :: load-ls-e3d928e745cc19bc5726ef9639c9175af4deabdf2a5e1086962946f2ae18e96a

# Navigate to core path
cd ../../.. || exit 1

# Body

# If the run has already been run before, it can be skipped
if [ -f "temp/runs/load-ls-e3d928e745cc19bc5726ef9639c9175af4deabdf2a5e1086962946f2ae18e96a/logs_ns3/finished.txt" ] && [ $(< "temp/runs/load-ls-e3d928e745cc19bc5726ef9639c9175af4deabdf2a5e1086962946f2ae18e96a/logs_ns3/finished.txt") == "Yes" ] ; then
    exit 0
fi

# Perform the run
cd frameworks/ns-3-bs/ns-3 || exit 1
./waf --run="main-full-pfifo-protocol --run_dir='../../../temp/runs/load-ls-e3d928e745cc19bc5726ef9639c9175af4deabdf2a5e1086962946f2ae18e96a'" || exit 1

