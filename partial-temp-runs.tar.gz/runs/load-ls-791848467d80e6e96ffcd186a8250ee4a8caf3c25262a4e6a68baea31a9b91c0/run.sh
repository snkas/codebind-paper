#!/bin/bash

# load-ls-main :: load-ls-791848467d80e6e96ffcd186a8250ee4a8caf3c25262a4e6a68baea31a9b91c0

# Navigate to core path
cd ../../.. || exit 1

# Body

# If the run has already been run before, it can be skipped
if [ -f "temp/runs/load-ls-791848467d80e6e96ffcd186a8250ee4a8caf3c25262a4e6a68baea31a9b91c0/logs_ns3/finished.txt" ] && [ $(< "temp/runs/load-ls-791848467d80e6e96ffcd186a8250ee4a8caf3c25262a4e6a68baea31a9b91c0/logs_ns3/finished.txt") == "Yes" ] ; then
    exit 0
fi

# Perform the run
cd frameworks/ns-3-bs/ns-3 || exit 1
./waf --run="main-full-pfifo-protocol --run_dir='../../../temp/runs/load-ls-791848467d80e6e96ffcd186a8250ee4a8caf3c25262a4e6a68baea31a9b91c0'" || exit 1

