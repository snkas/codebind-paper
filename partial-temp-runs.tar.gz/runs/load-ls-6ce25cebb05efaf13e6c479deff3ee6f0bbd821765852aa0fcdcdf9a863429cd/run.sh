#!/bin/bash

# load-ls-main :: load-ls-6ce25cebb05efaf13e6c479deff3ee6f0bbd821765852aa0fcdcdf9a863429cd

# Navigate to core path
cd ../../.. || exit 1

# Body

# If the run has already been run before, it can be skipped
if [ -f "temp/runs/load-ls-6ce25cebb05efaf13e6c479deff3ee6f0bbd821765852aa0fcdcdf9a863429cd/logs_ns3/finished.txt" ] && [ $(< "temp/runs/load-ls-6ce25cebb05efaf13e6c479deff3ee6f0bbd821765852aa0fcdcdf9a863429cd/logs_ns3/finished.txt") == "Yes" ] ; then
    exit 0
fi

# Perform the run
cd frameworks/ns-3-bs/ns-3 || exit 1
./waf --run="main-full-pfifo-protocol --run_dir='../../../temp/runs/load-ls-6ce25cebb05efaf13e6c479deff3ee6f0bbd821765852aa0fcdcdf9a863429cd'" || exit 1

