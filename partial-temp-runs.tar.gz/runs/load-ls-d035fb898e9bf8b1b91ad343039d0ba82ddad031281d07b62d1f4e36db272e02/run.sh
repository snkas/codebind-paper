#!/bin/bash

# load-ls-main :: load-ls-d035fb898e9bf8b1b91ad343039d0ba82ddad031281d07b62d1f4e36db272e02

# Navigate to core path
cd ../../.. || exit 1

# Body

# If the run has already been run before, it can be skipped
if [ -f "temp/runs/load-ls-d035fb898e9bf8b1b91ad343039d0ba82ddad031281d07b62d1f4e36db272e02/logs_ns3/finished.txt" ] && [ $(< "temp/runs/load-ls-d035fb898e9bf8b1b91ad343039d0ba82ddad031281d07b62d1f4e36db272e02/logs_ns3/finished.txt") == "Yes" ] ; then
    exit 0
fi

# Perform the run
cd frameworks/ns-3-bs/ns-3 || exit 1
./waf --run="main-full-pfifo-protocol --run_dir='../../../temp/runs/load-ls-d035fb898e9bf8b1b91ad343039d0ba82ddad031281d07b62d1f4e36db272e02'" || exit 1

