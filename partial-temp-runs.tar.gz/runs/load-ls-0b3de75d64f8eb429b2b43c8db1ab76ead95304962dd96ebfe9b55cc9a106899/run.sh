#!/bin/bash

# load-ls-main :: load-ls-0b3de75d64f8eb429b2b43c8db1ab76ead95304962dd96ebfe9b55cc9a106899

# Navigate to core path
cd ../../.. || exit 1

# Body

# If the run has already been run before, it can be skipped
if [ -f "temp/runs/load-ls-0b3de75d64f8eb429b2b43c8db1ab76ead95304962dd96ebfe9b55cc9a106899/logs_ns3/finished.txt" ] && [ $(< "temp/runs/load-ls-0b3de75d64f8eb429b2b43c8db1ab76ead95304962dd96ebfe9b55cc9a106899/logs_ns3/finished.txt") == "Yes" ] ; then
    exit 0
fi

# Perform the run
cd frameworks/ns-3-bs/ns-3 || exit 1
./waf --run="main-full-pfifo-protocol --run_dir='../../../temp/runs/load-ls-0b3de75d64f8eb429b2b43c8db1ab76ead95304962dd96ebfe9b55cc9a106899'" || exit 1

