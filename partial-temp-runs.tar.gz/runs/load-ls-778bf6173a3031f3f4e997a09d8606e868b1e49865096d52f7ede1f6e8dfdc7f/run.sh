#!/bin/bash

# load-ls-main :: load-ls-778bf6173a3031f3f4e997a09d8606e868b1e49865096d52f7ede1f6e8dfdc7f

# Navigate to core path
cd ../../.. || exit 1

# Body

# If the run has already been run before, it can be skipped
if [ -f "temp/runs/load-ls-778bf6173a3031f3f4e997a09d8606e868b1e49865096d52f7ede1f6e8dfdc7f/logs_ns3/finished.txt" ] && [ $(< "temp/runs/load-ls-778bf6173a3031f3f4e997a09d8606e868b1e49865096d52f7ede1f6e8dfdc7f/logs_ns3/finished.txt") == "Yes" ] ; then
    exit 0
fi

# Perform the run
cd frameworks/ns-3-bs/ns-3 || exit 1
./waf --run="main-full-pfifo-protocol --run_dir='../../../temp/runs/load-ls-778bf6173a3031f3f4e997a09d8606e868b1e49865096d52f7ede1f6e8dfdc7f'" || exit 1

