#!/bin/bash

# load-ls-main :: load-ls-a591af72343cc2ce9b88fe51a93c8f0addc35a8c01c8bbbddd85d748f36b4e87

# Navigate to core path
cd ../../.. || exit 1

# Body

# If the run has already been run before, it can be skipped
if [ -f "temp/runs/load-ls-a591af72343cc2ce9b88fe51a93c8f0addc35a8c01c8bbbddd85d748f36b4e87/logs_ns3/finished.txt" ] && [ $(< "temp/runs/load-ls-a591af72343cc2ce9b88fe51a93c8f0addc35a8c01c8bbbddd85d748f36b4e87/logs_ns3/finished.txt") == "Yes" ] ; then
    exit 0
fi

# Perform the run
cd frameworks/ns-3-bs/ns-3 || exit 1
./waf --run="main-full-pfifo-protocol --run_dir='../../../temp/runs/load-ls-a591af72343cc2ce9b88fe51a93c8f0addc35a8c01c8bbbddd85d748f36b4e87'" || exit 1

