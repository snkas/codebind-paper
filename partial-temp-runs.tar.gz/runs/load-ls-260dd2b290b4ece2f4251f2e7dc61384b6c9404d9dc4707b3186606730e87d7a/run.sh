#!/bin/bash

# load-ls-main :: load-ls-260dd2b290b4ece2f4251f2e7dc61384b6c9404d9dc4707b3186606730e87d7a

# Navigate to core path
cd ../../.. || exit 1

# Body

# If the run has already been run before, it can be skipped
if [ -f "temp/runs/load-ls-260dd2b290b4ece2f4251f2e7dc61384b6c9404d9dc4707b3186606730e87d7a/logs_ns3/finished.txt" ] && [ $(< "temp/runs/load-ls-260dd2b290b4ece2f4251f2e7dc61384b6c9404d9dc4707b3186606730e87d7a/logs_ns3/finished.txt") == "Yes" ] ; then
    exit 0
fi

# Perform the run
cd frameworks/ns-3-bs/ns-3 || exit 1
./waf --run="main-full-pfifo-protocol --run_dir='../../../temp/runs/load-ls-260dd2b290b4ece2f4251f2e7dc61384b6c9404d9dc4707b3186606730e87d7a'" || exit 1

