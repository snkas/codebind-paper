#!/bin/bash

# load-ls-main :: load-ls-b711b72725af9f0f207506710dc2ead56dad803d60b943e7d79f41ece93dba50

# Navigate to core path
cd ../../.. || exit 1

# Body

# If the run has already been run before, it can be skipped
if [ -f "temp/runs/load-ls-b711b72725af9f0f207506710dc2ead56dad803d60b943e7d79f41ece93dba50/logs_ns3/finished.txt" ] && [ $(< "temp/runs/load-ls-b711b72725af9f0f207506710dc2ead56dad803d60b943e7d79f41ece93dba50/logs_ns3/finished.txt") == "Yes" ] ; then
    exit 0
fi

# Perform the run
cd frameworks/ns-3-bs/ns-3 || exit 1
./waf --run="main-full-pfifo-protocol --run_dir='../../../temp/runs/load-ls-b711b72725af9f0f207506710dc2ead56dad803d60b943e7d79f41ece93dba50'" || exit 1

