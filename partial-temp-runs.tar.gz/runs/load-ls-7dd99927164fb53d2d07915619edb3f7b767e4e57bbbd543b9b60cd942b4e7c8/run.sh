#!/bin/bash

# load-ls-main :: load-ls-7dd99927164fb53d2d07915619edb3f7b767e4e57bbbd543b9b60cd942b4e7c8

# Navigate to core path
cd ../../.. || exit 1

# Body

# If the run has already been run before, it can be skipped
if [ -f "temp/runs/load-ls-7dd99927164fb53d2d07915619edb3f7b767e4e57bbbd543b9b60cd942b4e7c8/logs_ns3/finished.txt" ] && [ $(< "temp/runs/load-ls-7dd99927164fb53d2d07915619edb3f7b767e4e57bbbd543b9b60cd942b4e7c8/logs_ns3/finished.txt") == "Yes" ] ; then
    exit 0
fi

# Perform the run
cd frameworks/ns-3-bs/ns-3 || exit 1
./waf --run="main-full-pfifo-protocol --run_dir='../../../temp/runs/load-ls-7dd99927164fb53d2d07915619edb3f7b767e4e57bbbd543b9b60cd942b4e7c8'" || exit 1

