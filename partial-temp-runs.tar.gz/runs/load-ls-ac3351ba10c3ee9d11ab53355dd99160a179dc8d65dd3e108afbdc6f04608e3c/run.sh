#!/bin/bash

# load-ls-main :: load-ls-ac3351ba10c3ee9d11ab53355dd99160a179dc8d65dd3e108afbdc6f04608e3c

# Navigate to core path
cd ../../.. || exit 1

# Body

# If the run has already been run before, it can be skipped
if [ -f "temp/runs/load-ls-ac3351ba10c3ee9d11ab53355dd99160a179dc8d65dd3e108afbdc6f04608e3c/logs_ns3/finished.txt" ] && [ $(< "temp/runs/load-ls-ac3351ba10c3ee9d11ab53355dd99160a179dc8d65dd3e108afbdc6f04608e3c/logs_ns3/finished.txt") == "Yes" ] ; then
    exit 0
fi

# Perform the run
cd frameworks/ns-3-bs/ns-3 || exit 1
./waf --run="main-full-pfifo-protocol --run_dir='../../../temp/runs/load-ls-ac3351ba10c3ee9d11ab53355dd99160a179dc8d65dd3e108afbdc6f04608e3c'" || exit 1

