#!/bin/bash

# load-ls-main :: load-ls-4db7798c85376bd22f04e827ba89ea64d3d4659a794f1c220f1c9b71c6fa285a

# Navigate to core path
cd ../../.. || exit 1

# Body

# If the run has already been run before, it can be skipped
if [ -f "temp/runs/load-ls-4db7798c85376bd22f04e827ba89ea64d3d4659a794f1c220f1c9b71c6fa285a/logs_ns3/finished.txt" ] && [ $(< "temp/runs/load-ls-4db7798c85376bd22f04e827ba89ea64d3d4659a794f1c220f1c9b71c6fa285a/logs_ns3/finished.txt") == "Yes" ] ; then
    exit 0
fi

# Perform the run
cd frameworks/ns-3-bs/ns-3 || exit 1
./waf --run="main-full-pfifo-protocol --run_dir='../../../temp/runs/load-ls-4db7798c85376bd22f04e827ba89ea64d3d4659a794f1c220f1c9b71c6fa285a'" || exit 1

