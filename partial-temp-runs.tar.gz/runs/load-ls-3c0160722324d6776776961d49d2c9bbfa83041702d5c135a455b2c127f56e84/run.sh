#!/bin/bash

# load-ls-main :: load-ls-3c0160722324d6776776961d49d2c9bbfa83041702d5c135a455b2c127f56e84

# Navigate to core path
cd ../../.. || exit 1

# Body

# If the run has already been run before, it can be skipped
if [ -f "temp/runs/load-ls-3c0160722324d6776776961d49d2c9bbfa83041702d5c135a455b2c127f56e84/logs_ns3/finished.txt" ] && [ $(< "temp/runs/load-ls-3c0160722324d6776776961d49d2c9bbfa83041702d5c135a455b2c127f56e84/logs_ns3/finished.txt") == "Yes" ] ; then
    exit 0
fi

# Perform the run
cd frameworks/ns-3-bs/ns-3 || exit 1
./waf --run="main-full-pfifo-protocol --run_dir='../../../temp/runs/load-ls-3c0160722324d6776776961d49d2c9bbfa83041702d5c135a455b2c127f56e84'" || exit 1

