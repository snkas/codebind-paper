#!/bin/bash

# load-ls-main :: load-ls-051648b1b2d8d25781e3099e84d83e2076d0ab2bb7d11e4c4c6956918a7a8697

# Navigate to core path
cd ../../.. || exit 1

# Body

# If the run has already been run before, it can be skipped
if [ -f "temp/runs/load-ls-051648b1b2d8d25781e3099e84d83e2076d0ab2bb7d11e4c4c6956918a7a8697/logs_ns3/finished.txt" ] && [ $(< "temp/runs/load-ls-051648b1b2d8d25781e3099e84d83e2076d0ab2bb7d11e4c4c6956918a7a8697/logs_ns3/finished.txt") == "Yes" ] ; then
    exit 0
fi

# Perform the run
cd frameworks/ns-3-bs/ns-3 || exit 1
./waf --run="main-full-pfifo-protocol --run_dir='../../../temp/runs/load-ls-051648b1b2d8d25781e3099e84d83e2076d0ab2bb7d11e4c4c6956918a7a8697'" || exit 1

